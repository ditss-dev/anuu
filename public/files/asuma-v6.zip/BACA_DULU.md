```#jangan make panel abal abal (murah) kena backdoor nyalahin gw kan goblok😂
# pinter dikit kalo beli"
```

Script ini tidak support wa bisnis karna button!!!

# penting:
harap lapor kalo ada yang error.
```
