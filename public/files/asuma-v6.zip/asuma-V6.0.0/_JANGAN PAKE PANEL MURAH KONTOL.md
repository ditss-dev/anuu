```jangan make panel murah kena backdoor nyalahin gw kan goblok😂



```
# my contact: +6281513607731

# my saluran: https://whatsapp.com/channel/0029VaimJO0E50UaXv9Z1J0L

# my ress api: api.ditss.my.id

# my wibesite store: ditss.store