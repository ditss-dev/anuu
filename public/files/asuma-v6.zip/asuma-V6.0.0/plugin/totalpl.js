const fs = require("fs");
const path = require("path");
const pluginsFolderPath = './plugin';
let handler = async (m, { pulsar, prefix, command }) => {
  try {
    const pluginFiles = fs.readdirSync(pluginsFolderPath);
    const jsFiles = pluginFiles.filter(file => file.endsWith(".js"));
    if (jsFiles.length === 0) {
      return m.reply("Tidak ada file plugin ditemukan di folder plugins.");
    }
    let detectedCommands = 0;
    for (const file of jsFiles) {
      const filePath = path.join(pluginsFolderPath, file);
      const fileContent = fs.readFileSync(filePath, "utf8");
      const commandMatches = fileContent.match(/handler\.command\s*=\s*\[(.*?)\]/);
      if (commandMatches) {
        const commands = commandMatches[1].split(',').map(cmd => cmd.trim().replace(/['"]/g, ''));
        detectedCommands += commands.length;
      }
    }
    if (detectedCommands > 0) {
      m.reply(`Jumlah file plugin: ${jsFiles.length}\nJumlah handler.command yang terdeteksi: ${detectedCommands}`);
    } else {
      m.reply("Tidak ada handler.command yang ditemukan dalam file plugin.");
    }
  } catch (error) {
    console.error(error);
    m.reply("Terjadi kesalahan saat memeriksa file plugin.");
  }
};

handler.help = ["totalplug"];
handler.tags = ["plugin"];
handler.command = ["totalplug", "totalplugin", "totalpl"];

module.exports = handler;
