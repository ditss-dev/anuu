const fs = require("fs");

let handler = async (m, { Ditss, isCreator, isPremium, text, Reply }) => {
 // if (!isCreator && !isPremium) return Reply(global.mess.owner);

  let teksHeader = `
🌍 乂 *Layanan Nokos WhatsApp* 乂 🌍
Silakan pilih negara di bawah untuk membeli nomor WhatsApp.`;

  let buttons = [
    {
      buttonId: "buy_nokos_action",
      buttonText: { displayText: "Beli Nomor WhatsApp" },
      type: 4,
      nativeFlowInfo: {
        name: "single_select",
        paramsJson: JSON.stringify({
          title: "Pilih Negara",
          sections: [
            {
              title: "Negara Tersedia",
              rows: [
                { title: "Indonesia", description: "Nokos WhatsApp ID", id: `.prosesnokos whatsapp id` },
                { title: "Amerika", description: "Nokos WhatsApp US", id: `.prosesnokos whatsapp us` },
                { title: "Malaysia", description: "Nokos WhatsApp MY", id: `.prosesnokos whatsapp my` },
                { title: "Belanda", description: "Nokos WhatsApp NL", id: `.prosesnokos whatsapp nl` },
                { title: "Inggris", description: "Nokos WhatsApp GB", id: `.prosesnokos whatsapp gb` },
                // kamu bisa tambahkan negara lain di sini sesuai list dari Virtusim
              ],
            },
          ],
        }),
      },
    },
  ];

  Ditss.sendMessage(
    m.chat,
    {
      text: teksHeader,
      footer: "Ditss Store - Auto Nokos WhatsApp",
      buttons,
      headerType: 1,
      viewOnce: true,
    },
    { quoted: m }
  );
};

handler.command = ["buy_nokos", "nokosv2"];
module.exports = handler;