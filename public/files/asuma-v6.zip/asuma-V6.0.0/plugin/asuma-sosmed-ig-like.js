const fs = require("fs");

let handler = async (m, { Ditss, isCreator, isPremium, text, Reply, example }) => {
//  if (!isCreator && !isPremium) return Reply(global.mess.owner);
if (!text) return m.reply(example("username / link IG"));

  let teksHeader = `乂 𝗟𝗜𝗞𝗘 𝗜𝗡𝗦𝗧𝗔𝗚𝗥𝗔𝗠\n\nSilakan pilih jenis like sesuai kebutuhan.`;

  let buttons = [
    {
      buttonId: "likesosmed",
      buttonText: { displayText: "Pilih Jumlah Like" },
      type: 4,
      nativeFlowInfo: {
        name: "single_select",
        paramsJson: JSON.stringify({
          title: "Pilih Paket Instagram Like",
          sections: [
            {
              title: "🌍 World Bule (Global Like)",
              rows: [
                { title: "500 Like - 6k", description: `Target: ${text}`, id: `.buy_like world 500 ${text}` },
                { title: "1000 Like - 11k", description: `Target: ${text}`, id: `.buy_like world 1000 ${text}` },
                { title: "2000 Like - 21k", description: `Target: ${text}`, id: `.buy_like world 2000 ${text}` },
              ],
            },
            {
              title: "🇮🇩 Indonesia Real",
              rows: [
                { title: "100 Like - 13k", description: `Target: ${text}`, id: `.buy_like indo 100 ${text}` },
                { title: "200 Like - 25k", description: `Target: ${text}`, id: `.buy_like indo 200 ${text}` },
                { title: "500 Like - 55k", description: `Target: ${text}`, id: `.buy_like indo 500 ${text}` },
              ],
            },
          ],
        }),
      },
    },
  ];

  Ditss.sendMessage(
    m.chat,
    {
      text: teksHeader,
      footer: `© powered by ${global.namaowner}`,
      buttons,
      headerType: 1,
      viewOnce: true,
    },
    { quoted: m }
  );
};

handler.command = ["likesosmed", "likes"];

module.exports = handler;