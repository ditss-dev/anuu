const fs = require("fs")
const ki = "\`"
const ka = "\`"
const os = require('os');

let handler = async (m, { Ditss, isCreator, isPremium, qtext, runtime, toIDR, qkontak, pickRandom, readmore, fetchJson }) => {

const asumaByDits = `*\`乂 CPANEL M E N U 乂\`*

> └  ◦ *${ki}clearadmin-s3${ka}* :
> ┌  ◦ *${ki}clearall-s3${ka}* : 
> └  ◦ *${ki}clearuser-s3${ka}* :
> ┌  ◦ *${ki}listadmin-s3${ka}* : 
> └  ◦ *${ki}listpanel-s3${ka}* :
> ┌  ◦ *${ki}deladmin-s3${ka}* : 
> └  ◦ *${ki}delpanel-s3${ka}* :
> ┌  ◦ *${ki}cadmin-s3${ka}* : 
> └  ◦ *${ki}rusuhpanel-s3${ka}* :
> ┌  ◦ *${ki}1gb-s3${ka}* : 
> └  ◦ *${ki}2gb-s3${ka}* :
> ┌  ◦ *${ki}3gb-s3${ka}* : 
> └  ◦ *${ki}4gb-s3${ka}* :
> ┌  ◦ *${ki}5gb-s3${ka}* : 
> └  ◦ *${ki}6gb-s3${ka}* :
> ┌  ◦ *${ki}7gb-s3${ka}* : 
> └  ◦ *${ki}8gb-s3${ka}* :
> ┌  ◦ *${ki}9gb-s3${ka}* : 
> └  ◦ *${ki}10gb-s3${ka}* :
> ┌  ◦ *${ki}11gb-s3${ka}* : 
> └  ◦ *${ki}12gb-s3${ka}* :
> ┌  ◦ *${ki}13gb-s3${ka}* : 
> └  ◦ *${ki}14gb-s3${ka}* :
> ┌  ◦ *${ki}15gb-s3${ka}* : 
> └  ◦ *${ki}16gb-s3${ka}* :
> ┌  ◦ *${ki}17gb-s3${ka}* : 
> └  ◦ *${ki}18gb-s3${ka}* :
> ┌  ◦ *${ki}19gb-s3${ka}* : 
> └  ◦ *${ki}20gb-s3${ka}* :
> ┌  ◦ *${ki}unli-s3${ka}* : 
> └  ◦ *${ki}hackbackpanel-s3${ka}* :
`

const resize = async(buffer, ukur1, ukur2) => {

 return new Promise(async(resolve, reject) => {

 let jimp = require('jimp')

 var baper = await jimp.read(buffer);

 var ab = await baper.resize(ukur1, ukur2).getBufferAsync(jimp.MIME_JPEG)

 resolve(ab)

 })

}

Ditss.sendMessage(m?.chat, {

    document: fs.readFileSync("./asuma-Ditss.js"),

    jpegThumbnail: fs.readFileSync("./media/menu.jpg"),

    fileName: `${global.namaowner}`,

    fileLength: 99999999999999,

    pageCount: "100",

    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',

//bts
 caption: asumaByDits,
 footer: `powered by ${global.namaowner}`,
 buttons: [
 {
 buttonId: ".botjelek", 
 buttonText: {
 displayText: "back"
 }
 },{
 buttonId: ".asuma-panel4", 
 buttonText: {
 displayText: "server 4"
 }
 }
 ],

 viewOnce: true,

 headerType: 6,

 contextInfo: {

 isForwarded: true,

 forwardingScore: 99999,

 externalAdReply: {

 showAdAttribution: true,

 title: `${global.namaowner} | ${global.namabot}`,

 mediaType: 1,

 previewType: 1,

 body: `©Ditss`, //© artinya hak cipta 

 previewType: "PHOTO",

 thumbnail: fs.readFileSync('./media/menu.jpg'),

 renderLargerThumbnail: true,

 mediaUrl: my.gc,

 sourceUrl: my.gc,

 },

 forwardedNewsletterMessageInfo: {

 newsletterJid: my.idch,

 serverMessageId: -1,

 newsletterName: `Menu By: ${namaowner}`,

 }

 }

}, { quoted: qkontak });

let pler = await fetchJson('https://raw.githubusercontent.com/ditss-dev/database/main/music.json');

let itil = pler[Math.floor(Math.random() * pler.length)];

await Ditss.sendMessage(m.chat, { audio:{url: itil},mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: fdoc })}

handler.command = ["panelmenu3", "menupanel3", "asuma-panel3", "ditsspanel3"]

module.exports = handler