const fs = require("fs")
const os = require('os');
let handler = async (m, { Ditss, isCreator, isPremium, qtext, runtime, fdoc, qkontak, pickRandom, readmore, fetchJson, fvn }) => {
const asumaByDits = `${global.menujadibot}`
const resize = async(buffer, ukur1, ukur2) => {
 return new Promise(async(resolve, reject) => {

 let jimp = require('jimp')

 var baper = await jimp.read(buffer);

 var ab = await baper.resize(ukur1, ukur2).getBufferAsync(jimp.MIME_JPEG)

 resolve(ab)

 })

}

Ditss.sendMessage(m?.chat, {

    document: fs.readFileSync("./asuma-Ditss.js"),

    jpegThumbnail: fs.readFileSync("./media/menu.jpg"),

    fileName: `${global.namaowner}`,

    fileLength: 99999999999999,

    pageCount: "100",

    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',

//bts

 caption: asumaByDits,

 footer: `powered by ${global.namaowner}`,

 buttons: [

 {

 buttonId: ".jadibot-scan", 

 buttonText: {

 displayText: "Jadi Bot scan"

 }

 },{

 buttonId: ". jadibot-pairing", 

 buttonText: {

 displayText: "Jadi Bot Pairing"

 }

 }],

 viewOnce: true,

 headerType: 6,

 contextInfo: {

 isForwarded: true,

 forwardingScore: 99999,

 externalAdReply: {

 showAdAttribution: true,

 title: `${global.namaowner} | ${global.namabot}`,

 mediaType: 1,

 previewType: 1,

 body: `©Ditss`, //© artinya hak cipta 

 previewType: "PHOTO",

 thumbnail: fs.readFileSync('./media/menu.jpg'),

 renderLargerThumbnail: true,

 mediaUrl: my.gc,

 sourceUrl: my.gc,

 },

 forwardedNewsletterMessageInfo: {

 newsletterJid: my.idch,

 serverMessageId: -1,

 newsletterName: `Menu By: ${namaowner}`,

 }

 }

}, { quoted: qkontak });

let pler = await fetchJson('https://raw.githubusercontent.com/ditss-dev/database/main/music.json');

let itil = pler[Math.floor(Math.random() * pler.length)];

await Ditss.sendMessage(m.chat, { audio:{url: itil},mimetype: 'audio/mp4', ptt: true, fileLength: 88738}, { quoted: fdoc })}
handler.command = ["jadibot", "jadibotmenu", "asuma-jadibot", "ditssjadibot"]
module.exports = handler