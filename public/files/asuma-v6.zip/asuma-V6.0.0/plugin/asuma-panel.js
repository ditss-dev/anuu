const fs = require("fs")

const os = require('os');
const ki = "\`"
const ka = "\`"
let handler = async (m, { Ditss, isCreator, isPremium, qtext, runtime, toIDR, qkontak, pickRandom, readmore, fetchJson, fdoc }) => {
const asumaByDits = `*\`乂 CPANEL M E N U 乂\`*

> └  ◦ *${ki}clearadmin${ka}* :
> ┌  ◦ *${ki}clearall${ka}* : 
> └  ◦ *${ki}clearuser${ka}* :
> ┌  ◦ *${ki}listadmin${ka}* : 
> └  ◦ *${ki}listpanel${ka}* :
> ┌  ◦ *${ki}deladmin${ka}* : 
> └  ◦ *${ki}delpanel${ka}* :
> ┌  ◦ *${ki}cadmin${ka}* : 
> └  ◦ *${ki}risuhpanel${ka}* :
> ┌  ◦ *${ki}1gb${ka}* : 
> └  ◦ *${ki}2gb${ka}* :
> ┌  ◦ *${ki}3gb${ka}* : 
> └  ◦ *${ki}4gb${ka}* :
> ┌  ◦ *${ki}5gb${ka}* : 
> └  ◦ *${ki}6gb${ka}* :
> ┌  ◦ *${ki}7gb${ka}* : 
> └  ◦ *${ki}8gb${ka}* :
> ┌  ◦ *${ki}9gb${ka}* : 
> └  ◦ *${ki}10gb${ka}* :
> ┌  ◦ *${ki}11gb${ka}* : 
> └  ◦ *${ki}12gb${ka}* :
> ┌  ◦ *${ki}13gb${ka}* : 
> └  ◦ *${ki}14gb${ka}* :
> ┌  ◦ *${ki}15gb${ka}* : 
> └  ◦ *${ki}16gb${ka}* :
> ┌  ◦ *${ki}17gb${ka}* : 
> └  ◦ *${ki}18gb${ka}* :
> ┌  ◦ *${ki}19gb${ka}* : 
> └  ◦ *${ki}20gb${ka}* :
> ┌  ◦ *${ki}unli${ka}* : 
> └  ◦ *${ki}hackbackpanel${ka}* :
`

const resize = async(buffer, ukur1, ukur2) => {

 return new Promise(async(resolve, reject) => {

 let jimp = require('jimp')

 var baper = await jimp.read(buffer);

 var ab = await baper.resize(ukur1, ukur2).getBufferAsync(jimp.MIME_JPEG)

 resolve(ab)

 })

}

Ditss.sendMessage(m?.chat, {

    document: fs.readFileSync("./asuma-Ditss.js"),

    jpegThumbnail: fs.readFileSync("./media/menu.jpg"),

    fileName: `${global.namaowner}`,

    fileLength: 99999999999999,

    pageCount: "100",

    mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',

//bts
 caption: asumaByDits,
 footer: `powered by ${global.namaowner}`,
 buttons: [
 {
 buttonId: ".botjelek", 
 buttonText: {
 displayText: "back"
 }
 },{
 buttonId: ".asuma-panel2", 
 buttonText: {
 displayText: "server 2"
 }
 }
 ],

 viewOnce: true,

 headerType: 6,

 contextInfo: {

 isForwarded: true,

 forwardingScore: 99999,

 externalAdReply: {

 showAdAttribution: true,

 title: `${global.namaowner} | ${global.namabot}`,

 mediaType: 1,

 previewType: 1,

 body: `©Ditss`, //© artinya hak cipta 

 previewType: "PHOTO",

 thumbnail: fs.readFileSync('./media/menu.jpg'),

 renderLargerThumbnail: true,

 mediaUrl: my.gc,

 sourceUrl: my.gc,

 },

 forwardedNewsletterMessageInfo: {

 newsletterJid: my.idch,

 serverMessageId: -1,

 newsletterName: `Menu By: ${namaowner}`,

 }

 }

}, { quoted: qkontak });

let pler = await fetchJson('https://raw.githubusercontent.com/ditss-dev/database/main/music.json');

let itil = pler[Math.floor(Math.random() * pler.length)];

await Ditss.sendMessage(m.chat, { audio:{url: itil},mimetype: 'audio/mp4', ptt: true, fileLength: 99999999999}, { quoted: fdoc })}

handler.command = ["panelmenu", "menupanel", "asuma-panel", "ditsspanel"]

module.exports = handler