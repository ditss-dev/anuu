
# Install di Pannel ⚙️:
```
masukan cmd
•1 add file dipanel asuma.zip jngn lupa unarchive
•2 jika sudah masukan cmd npm start
•3 keluar code pairing, masukan kode pairing ke nomor yg mau jadibot
•4 tinggal pakai
•5 note: harap jangan memakai panel murah.

Error? Modul Not Found?
tandanya panel nggk kuat gini caranya 
•1 npm start ganti ke yarn
•2 jika sudah selesai yarn ganti ke npm start lagi
•3 tinggal pakai ( harap jangan memakai panel murah ) 
•4 selesai
```
[ sc ini tidak support wa bisnis karna button. ]
///////////////////////////////////////////

Thanks To!!
 - Ditss 
 - buyer gw
 - yang dah support dari 0
 - iky ( support )
 - raka ( support )
 - putra ( support )
 - kiyoo ( base )
 - siputx ( base )
 - pulsar 
 - qioo
 - vreden
 - Lyosh
 - Orang
 - zaenishi
 - anabot
 - penyedia ress api ( free )
 - Creator Botz
 - Yang Punya Base
 - Dan Lainya 🙏
#Ditss - 2025 - Jum'at - 24 maret



# perlu di ingatkan jangan menggunakan panel murah. yang banyak admin panel nya beli nya jangan abal abal. kena backdoor jangan salahkan sc! salahkan diri anda sendiri.