const fs = require('fs')
const chalk = require('chalk')
const { TelegraPh } = require('./uploader')
const { getRandom, smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetchJson, await, sleep } = require('./myfunc')
//let setting = JSON.parse(fs.readFileSync('./config.json'));
const welcome2 = global.auto_welcomeMsg
const leave2 = global.auto_leaveMsg
const {
	delay,
    prepareWAMessageMedia,
	proto,
	jidDecode,
	jidNormalizedUser,
	generateForwardMessageContent,
	generateWAMessageFromContent,
	downloadContentFromMessage,
} = require('@whiskeysockets/baileys')
const moment = require('moment-timezone')
const ments = (text) => {return text.match('@') ? [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net') : []}
module.exports.welcome = async(iswel, isleft, Ditss, anu) =>{
    
Ditss.sendButtonImagee = async (jid, buttons, quoted, opts = {}) => {
      var image = await prepareWAMessageMedia({
         image: {
            url: opts && opts.image ? opts.image : ''
         }
      }, {
         upload: Ditss.waUploadToServer
      })
      let message = generateWAMessageFromContent(jid, {
         viewOnceMessage: {
            message: {
               interactiveMessage: {
                  body: {
                     text: opts && opts.body ? opts.body : ''
                  },
                  footer: {
                     text: opts && opts.footer ? opts.footer : ''
                  },
                  header: {
                     hasMediaAttachment: true,
                     imageMessage: image.imageMessage,
                  },
                  nativeFlowMessage: {
                     buttons: buttons,
                     messageParamsJson: ''
                  }
               }
            }
         }
      }, {
         quoted
      })
      await Ditss.sendPresenceUpdate('composing', jid)
      return Ditss.relayMessage(jid, message["message"], {
         messageId: message.key.id
      })
   }    
	try {
            const metadata = await Ditss.groupMetadata(anu.id)
            const participants = anu.participants
            const memeg = metadata.participants.length;
  	        const groupName = metadata.subject
  		      const groupDesc = metadata.desc
  		      
            for (let num of participants) {
  		      const fkontaku = { key: {participant: `0@s.whatsapp.net`, ...(anu.id ? { remoteJid: `status@broadcast` } : {}) }, message: { 'contactMessage': { 'displayName': ``, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;,;;;\nFN:,\nitem1.TEL;waid=${num.split('@')[0]}:${num.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`, 'jpegThumbnail': global.pathimg, thumbnail: global.pathimg,sendEphemeral: true}}}
                try {
                    pp_user = await Ditss.profilePictureUrl(num, 'image')
                } catch {
                    pp_user = 'https://telegra.ph/file/c3f3d2c2548cbefef1604.jpg'
                }

                try {
                    ppgroup = await Ditss.profilePictureUrl(anu.id, 'image')
                } catch {
                    ppgroup = 'https://telegra.ph/file/c3f3d2c2548cbefef1604.jpg'
                }
                      let profile;
      try {
        profile = await Ditss.profilePictureUrl(num, 'image');
      } catch {
        profile = 'https://telegra.ph/file/95670d63378f7f4210f03.png';
      }
      let imguser = await prepareWAMessageMedia({
        image: {
          url: profile
        }
      }, {
        upload: Ditss.waUploadToServer
      })
                if (anu.action == 'add' && (iswel || global.auto_welcomeMsg)) {

                	console.log(anu)
                if (global.db.data.chats[anu.id].setwelcome) {               	
                var get_teks_welcome = await global.db.data.chats[anu.id].setwelcome
                var replace_pesan = (get_teks_welcome.replace(/@user/gi, `@${num.split('@')[0]}`))
                var full_pesan = replace_pesan
  .replace(/@group/gi, groupName)
  .replace(/@desc/gi, groupDesc);
  
var add = `https://api.vreden.web.id/api/spotifyimage?image=https://files.catbox.moe/kdzwqc.jpg&title=Welcome Bro!&author=Asuma Ai&album=TERIMAKASIH TELAH BERGABUNG!`
var thumbadd = await getBuffer(profile);
               Ditss.sendMessage(anu.id, {
  footer: `dari atmin dan member`,
  buttons: [
    {
      buttonId: `.intro`,
      buttonText: { displayText: `hallo member baru @${Ditss.getName(num)}` },
      type: 1
    },
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync("./package.json"),
  fileName: `welcome user news</>`,
  mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  fileLength: 99999999,
  caption: full_pesan,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [num], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: global.my.idch,
   newsletterName: `haloo member ke ${metadata.participants.length}`
   }, 
    externalAdReply: {
      title: `${global.namabot} -`,
      body: `Status Group : ${metadata.announce == true ? "tertutup" : "terbuka"}`,
      thumbnailUrl: profile,
      sourceUrl: my.ch,
      mediaType: 1,
      renderLargerThumbnail: true,
    },
  },
});                } else {
                var add = `https://api.vreden.web.id/api/spotifyimage?image=https://files.catbox.moe/kdzwqc.jpg&title=Welcome Bro!&author=Pulsar AI&album=TERIMAKASIH TELAH BERGABUNG!`
                var thumbadd = await getBuffer(add)
               Ditss.sendMessage(anu.id, {
  footer: `dari atmin dan member`,
  buttons: [
    {
      buttonId: `.intro`,
      buttonText: { displayText: `hallo member baru @${Ditss.getName(num)}` },
      type: 1
    },
  ],
  headerType: 1,
  viewOnce: true,
  document: fs.readFileSync("./package.json"),
  fileName: `welcome user news</>`,
  mimetype: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  fileLength: 99999999,
  caption:  `\`S A M B U T A N\`\n\n
*SELAMAT DATANG KAK*
@${num.split("@")[0]}  


*👋 Aloo* @${num.split("@")[0]}!  
Selamat bergabung di *${groupName}*!`,
  contextInfo: {
   isForwarded: true, 
   mentionedJid: [num], 
   forwardedNewsletterMessageInfo: {
   newsletterJid: `120363314209665405@newsletter`,
   newsletterName: `haloo member ke ${metadata.participants.length}`
   }, 
    externalAdReply: {
      title: `${global.namabot} -`,
      body: `Status Group : ${metadata.announce == true ? "tertutup" : "terbuka"}`,
      thumbnailUrl: profile,
      sourceUrl: global.my.ch,
      mediaType: 1,
      renderLargerThumbnail: true,
    },
  },
});
                }
                } else if (anu.action == 'remove' && (isleft || global.auto_leaveMsg)) {
                	console.log(anu)
                		if (global.db.data.chats[anu.id].setleft) {            	
                        var get_teks_left = await global.db.data.chats[anu.id].setleft
                        var replace_pesan = (get_teks_left.replace(/@user/gi, `@${num.split('@')[0]}`))
                        var full_pesan = (replace_pesan.replace(/@group/gi, groupName).replace(/@desc/gi, groupDesc))
                var left = `https://api.vreden.web.id/api/spotifyimage?image=https://files.catbox.moe/kdzwqc.jpg&title=Bye Bye bro!&author=Pulsar AI&album=TERIMAKASIH TELAH BERGABUNG!`
                var thumbleft = await getBuffer(left)
               Ditss.sendButtonImagee(anu.id, [
 {
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"member beban kontol.🗿\",\"title\":\"byee\",\"id\":\".intro\"}" 
}
], null, {
 image: profile,
 body: full_pesan,
 footer: `\n🛒 ${global.namabot}`
});
                       } else {
                       var usr = Ditss.getName(num)
                var left = `https://api.vreden.web.id/api/spotifyimage?image=https://files.catbox.moe/kdzwqc.jpg&title=Bye Bye Bro!&author=Pulsar AI&album=TERIMAKASIH TELAH BERGABUNG!`
                var thumbleft = await getBuffer(left)
Ditss.sendButtonImagee(anu.id, [
 {
"name": "quick_reply", "buttonParamsJson": "{\"display_text\":\"member beban kontol.\",\"title\":\"bye\",\"id\":\".intro\"}" 
}
], null, {
 image: profile,
 body: `\`S E L A M A T - J A L A N\`\n\n*━━━✦✗✦━━━*  

👋 *SELAMAT JALAN*  

@${num.split("@")[0]}  

*━━━✦✗✦━━━*`,
 footer: `\n🛒 ${global.namabot}`
});
                        } 
                } else if (anu.action == 'promote') {
                var promm = await getBuffer(`https://telegra.ph/file/0f665e9f52aca8d9e13ca.jpg`)
                Ditss.sendMessage(anu.id, { text:  `*🎊 Selamat* @${num.split("@")[0]}, Kamu Menjadi Admin\n\n*Quote:*\n_Jadilah Pemimpin Yang Baek_`, contextInfo:{ mentionedJid:[num], "externalAdReply": {"showAdAttribution": true, "containsAutoReply": true, "title": `Selamat Kak🥳`, "body": `${global.ownerName}`, "previewType": "PHOTO", "thumbnailUrl": ``, "thumbnail": imguser, "sourceUrl": `${global.gcwa}`}}}, {quoted: fkontaku})
                } else if (anu.action == 'demote') {
                var demm = await getBuffer(`https://telegra.ph/file/527667156421dbe4c8d04.jpg`)
                Ditss.sendMessage(anu.id, { text:  `*😞 Yang Sabar* @${num.split("@")[0]}, Kamu Menjadi Orang Biasa\n\n*Quote:*\n_Hidup Itu Seperti Roda Kadang Diatas, Kadang Dibawah_`, contextInfo:{ mentionedJid:[num], "externalAdReply": {"showAdAttribution": true, "containsAutoReply": true, "title": `Yang Sabar Ya Boss🎭`, "body": `${global.ownerName}`, "previewType": "PHOTO", "thumbnailUrl": ``, "thumbnail": demm, "sourceUrl": `${global.gcwa}`}}}, {quoted: fkontaku})
              }
}
        } catch (err) {
            console.log(err)
            }
	}

module.exports.oneTime = async (setting,Ditss,m) => {
  if(global.antiViewOnce){
  			try {
let teks = `「 *ANTI VIEWONCE MESSAGE* 」
      
📛 *Name* : ${m.pushName}
👤 *User* : @${m.sender.split("@")[0]}
⏰ *Clock* : ${moment.tz('Asia/Jakarta').format('HH:mm:ss')} WIB  
✍️ *MessageType* : ${m.mtype}
💬 *Caption* : ${m.msg.caption ? m.msg.caption : "no caption"}`

await Ditss.sendTextWithMentions(m.chat, teks, m)
  await delay(500)

  m.copyNForward(m.chat, true, {
  readViewOnce: true,
    quoted: m
  })

			} catch (err) {
				console.log(err)
			}
  }
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(chalk.redBright(`Update ${__filename}`))
delete require.cache[file]
require(file)
})