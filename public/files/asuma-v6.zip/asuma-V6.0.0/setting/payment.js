const fs = require('fs');
const chalk = require('chalk');
//jangan di jual anak mmk🤓
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})