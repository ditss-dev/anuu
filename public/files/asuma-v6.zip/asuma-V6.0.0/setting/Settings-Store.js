//base skyzo 
/*
#asuma v2.8
- • ditss
*/

const fs = require('fs');
const chalk = require('chalk');
// Settings Bot 
global.DataPc = "120363360449876525@newsletter"
//ini mo di ganti gpp mo ga di ganti gpp jugaa
global.tekspushkonv2 = '' // gunakan teks ini jika user tidak mengisi teks
global.ApiVirtusim = "your key virtusim"; // Ganti dengan API Key dari VirtuSIM

// VIDEO ALLMENU 
global.Allmenu = "https://files.catbox.moe/kneh1x.mp4"
// SETTING LINODE
global.apilinode = '75a4103e2105b1bf8913542f88ef1de75e7bf93469fe131e39a4f840878e45ef'

// setting payment 
global.payt = {
    nodana: "081513607731",
    nama_dana: "aditya",
    nogopay: "081513607731",
    nama_gopay: "Aditia Nugraha",
    noovo: "081513607731",
    nama_ovo: "aditia Nugraha",
    qris: "https://img12.pixhost.to/images/1330/582340474_ditss.jpg"
}
// NAMA - STORE 
global.NameStore = "dītss.store"
global.idTesti = "120363326522441260@newsletter"//guna untuk mengirim ke saluran testi 

// cat artinya catalog
global.catScript = "https://wa.me/p/9804688406217114/6281513607731"
global.catPanel = "https://wa.me/p/28743274011954055/6281513607731"//produk panel
global.catProduk = "https://wa.me/c/6281513607731"
global.catNokos = "https://wa.me/p/28756808063966692/6281513607731"
global.linkOwner = "https://wa.me/31629821394"
global.linkGrup = "https://chat.whatsapp.com/FVlNkXGLLvXE9fkdgxviIK"
global.menuStore = "https://files.catbox.moe/cy44re.jpg"

// thumbnail Store {
global.thumbStore = "https://files.catbox.moe/wktobm.jpg"
// ======== ThumbNokos
global.thumbNokos = "https://img12.pixhost.to/images/1330/582340474_ditss.jpg"
//========= thumbnail Vps
global.thumbVps = "https://img12.pixhost.to/images/1330/582340467_ditss.jpg"
global.thumbNokosFs = fs.readFileSync('./media/logo-nokos.jpg');
global.pathimgg = fs.readFileSync('./media/bibir.jpg');
// thumbnail App Premium 
global.thumbApp = "https://img12.pixhost.to/images/1330/582340474_ditss.jpg"
// thumb Puksa
global.thumbPulsa = "https://img12.pixhost.to/images/1330/582340474_ditss.jpg"
// thumb Top up all game
global.thumbTopup = "https://files.catbox.moe/mbxbxu.jpg"
global.thumbSosmed = "https://files.catbox.moe/x9qrm3.jpg"
//thumb Cpanel
global.thumbCpanel = "https://img12.pixhost.to/images/689/572893406_ditss.jpg"


//thumbnail bot 
global.menu = "https://img12.pixhost.to/images/612/571937846_ditss.jpg";
global.thumbReply = "https://files.catbox.moe/j68npn.jpg"
global.larangan = "https://files.catbox.moe/q57r0k.jpg"
global.thumbOwner = "https://img12.pixhost.to/images/1256/581188763_ditss.jpg"
// THUMBNAIL PUSHKONTAK
global.pushviddeo = 'https://files.catbox.moe/kneh1x.mp4' //video
global.pushphoto = 'https://telegra.ph/file/8e8d0d6566764b6b9ce7e.jpg'


//=S=E=T=T=I=N=G - P=A=N=E=L=//
global.panel = "https://ditss.store"//domain panel
global.cred = "ptla_"// plta
global.apiuser = "ptlc_"//pltc
global.eggsnya = 15
global.netsnya = 5
global.location = "1"
//2. Cpanel s-2

//=S=E=T=T=I=N=G - P=A=N=E=L=//
global.panels2 = "https://ditss.store"//domain panel
global.creds2 = "ptla_"// plta
global.apiusers2 = "ptlc_"//pltc
global.eggsnyas2 = 15
global.netsnyas2 = 5
global.locations2 = "1"
//3. Cpanel s-3

//=S=E=T=T=I=N=G - P=A=N=E=L=//
global.panels3 = "https://ditss.store"//domain panel
global.creds3 = "ptla_"// plta
global.apiusers3 = "ptlc_"//pltc
global.eggsnyas3 = 15
global.netsnyas3 = 5
global.locations3 = "1"
//4. Cpanel s-4
//=S=E=T=T=I=N=G - P=A=N=E=L=//
global.panels4 = "https://ditss.store"//domain panel
global.creds4 = "ptla_"// plta
global.apiusers4 = "ptlc_"//pltc
global.eggsnyas4 = 15
global.netsnyas4 = 5
global.locations4 = "1"
//5. Cpanel s-5
//=S=E=T=T=I=N=G - P=A=N=E=L=//
global.panels5 = "https://ditss.store"//domain panel
global.creds5 = "ptla_"// plta
global.apiusers5 = "ptlc_"//pltc
global.eggsnyas5 = 15
global.netsnyas5 = 5
global.locations5 = "1"
// SETTING LINODE
global.apilinode = '75a4103e2105b1bf8913542f88ef1de75e7bf93469fe131e39a4f840878e45ef'
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})